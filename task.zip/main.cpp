#include "BMPReader.h"

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Не указан файл" << std::endl;
        return 1;
    }

    BMPReader bmp;
    if (bmp.openBMP(argv[1])) {
        bmp.displayBMP();
        bmp.closeBMP();
    }

    return 0;
}

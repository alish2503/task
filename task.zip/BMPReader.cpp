#include "BMPReader.h"

bool BMPReader::openBMP(const std::string& fileName) {
    fileStream.open(fileName, std::ios::binary);
    if (!fileStream) {
        std::cerr << "Не удалось открыть файл: " << fileName << std::endl;
        return false;
    }

    fileStream.read(reinterpret_cast<char*>(&fileHeader), sizeof(fileHeader));
    if (fileHeader.bfType != 0x4D42) {  
        std::cerr << "Это не BMP файл!" << std::endl;
        return false;
    }

    fileStream.read(reinterpret_cast<char*>(&infoHeader), sizeof(infoHeader));

    if (infoHeader.biBitCount != 24 && infoHeader.biBitCount != 32) {
        std::cerr << "Поддерживаются только 24 или 32 битные файлы." << std::endl;
        return false;
    }

    size_t pixelArraySize = fileHeader.bfSize - fileHeader.bfOffBits;
    pixelData.resize(pixelArraySize);
    fileStream.seekg(fileHeader.bfOffBits, std::ios::beg);
    fileStream.read(reinterpret_cast<char*>(pixelData.data()), pixelArraySize);

    return true;
}

void BMPReader::displayBMP() const {
    int width = infoHeader.biWidth;
    int height = abs(infoHeader.biHeight); 
    int bytesPerPixel = infoHeader.biBitCount / 8;
    int rowPadding = (4 - (width * (bytesPerPixel)) % 4) % 4; 
    for (int y = height-1; y >= 0; --y) {
        for (int x = 0; x < width; ++x) {
            int pixelIndex = (y * (width * (bytesPerPixel) + rowPadding)) + (x * (bytesPerPixel));

            uint8_t blue = pixelData[pixelIndex];
            uint8_t green = pixelData[pixelIndex + 1];
            uint8_t red = pixelData[pixelIndex + 2];

            if (red == 255 && green == 255 && blue == 255) {
                std::cout << " ";  
            } else if (red == 0 && green == 0 && blue == 0) {
                std::cout << "#";  
            } else {
                std::cerr << "Поддерживаются только черный и белый цвета." << std::endl;
                return;
            }
        }
        std::cout << std::endl;  
    }
}


void BMPReader::closeBMP() {
    if (fileStream.is_open()) {
        fileStream.close();
    }
}

BMPReader::~BMPReader() {
    closeBMP();
}

#ifndef BMPREADER_H
#define BMPREADER_H

#include "BMPHeader.h"
#include <fstream>
#include <vector> 
#include <iostream>

class BMPReader {
private:
    BMPFileHeader fileHeader;
    BMPInfoHeader infoHeader;
    std::vector<uint8_t> pixelData;
    std::ifstream fileStream;

public:
    bool openBMP(const std::string&);
    void displayBMP() const;
    void closeBMP(); 
    ~BMPReader();
};

#endif